#pragma once

#define MW_NAMESPACE namespace mw {
#define MMR_NAMESPACE namespace mmr {
#define TEST_NAMESPACE namespace test {
#define END_NAMESPACE }